package com.example.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.drawToBitmap
import com.example.data.KnowledgeStats
import com.example.data.TriggerSettings
import com.example.ui.theme.DotNoteTheme
import kotlinx.coroutines.flow.SharedFlow
import kotlin.math.roundToInt

private data class SampleQuizPrompt(
    val title: String,
    val question: String,
    val options: List<String>
)

private val SAMPLE_PROMPTS = listOf(
    SampleQuizPrompt(
        title = "Cell Biology",
        question = "Which organelle generates most of the cell's supply of ATP?",
        options = listOf(
            "A) Golgi apparatus",
            "B) Mitochondria",
            "C) Ribosome",
            "D) Lysosome"
        )
    ),
    SampleQuizPrompt(
        title = "Networking",
        question = "Which transport layer protocol provides connectionless delivery without guaranteed ordering?",
        options = listOf(
            "A) TCP",
            "B) UDP",
            "C) HTTP",
            "D) SSH"
        )
    ),
    SampleQuizPrompt(
        title = "Algorithms",
        question = "What is the time complexity of binary search on a sorted array?",
        options = listOf(
            "A) O(n)",
            "B) O(n log n)",
            "C) O(log n)",
            "D) O(1)"
        )
    )
)

@Composable
fun LiveTesterScreen(
    stats: KnowledgeStats,
    settings: TriggerSettings,
    isBusy: Boolean,
    liveTestResult: LiveTestResult?,
    volumeDownEvents: SharedFlow<Unit>,
    onRunBitmapScan: (Bitmap, Boolean) -> Unit,
    onReplayDot: () -> Unit,
    onClearResult: () -> Unit,
    onLoadSamplePack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var promptIndex by remember { mutableIntStateOf(0) }
    var customQuestion by remember { mutableStateOf(SAMPLE_PROMPTS[0].question) }
    var customOptions by remember { mutableStateOf(SAMPLE_PROMPTS[0].options) }
    var showEditDialog by remember { mutableStateOf(false) }

    var pickedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var quizCardViewRef by remember { mutableStateOf<ComposeView?>(null) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val loaded = decodeUriToBitmap(context, uri)
            if (loaded != null) {
                pickedBitmap = loaded
                onRunBitmapScan(loaded, false)
            }
        }
    }

    fun triggerCurrentScan() {
        val externalBmp = pickedBitmap
        if (externalBmp != null) {
            onRunBitmapScan(externalBmp, false)
        } else {
            val view = quizCardViewRef
            if (view != null && view.width > 0 && view.height > 0) {
                val captured = view.drawToBitmap(Bitmap.Config.ARGB_8888)
                onRunBitmapScan(captured, true)
            }
        }
    }

    LaunchedEffect(volumeDownEvents) {
        volumeDownEvents.collect {
            triggerCurrentScan()
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Offline OCR & Dot Tester",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text(
                        text = "Press Volume Down right here or tap Scan below to run real offline OCR + SQLite matching and flash the ${settings.dotDurationMs}ms black dot.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (stats.chunkCount == 0 && stats.mcqCount == 0) {
                item {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Knowledge base is empty",
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "Load sample notes or add your own in the Knowledge tab first.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            TextButton(onClick = onLoadSamplePack) {
                                Text("Load Sample")
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SAMPLE_PROMPTS.forEachIndexed { idx, sample ->
                        val selected = pickedBitmap == null && promptIndex == idx
                        FilledTonalButton(
                            onClick = {
                                pickedBitmap = null
                                promptIndex = idx
                                customQuestion = sample.question
                                customOptions = sample.options
                                onClearResult()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = sample.title,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            item {
                OutlinedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CenterFocusStrong,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (pickedBitmap != null) "UPLOADED SCREENSHOT" else "LIVE QUIZ SURFACE",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Row {
                                if (pickedBitmap == null) {
                                    IconButton(
                                        onClick = { showEditDialog = true },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Edit test question",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                } else {
                                    TextButton(onClick = {
                                        pickedBitmap = null
                                        onClearResult()
                                    }) {
                                        Text("Reset")
                                    }
                                }
                            }
                        }

                        // Captured Surface + Exact OCR-Coordinate Black Dot Overlay
                        BoxWithConstraints(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White)
                        ) {
                            val density = LocalDensity.current

                            if (pickedBitmap != null) {
                                val bmp = pickedBitmap!!
                                val aspect = bmp.width.toFloat() / bmp.height.coerceAtLeast(1).toFloat()
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = "Quiz screenshot for OCR test",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height((maxWidth.value / aspect).dp),
                                    contentScale = ContentScale.Fit
                                )
                            } else {
                                AndroidView(
                                    factory = { ctx ->
                                        ComposeView(ctx).also { quizCardViewRef = it }
                                    },
                                    update = { view ->
                                        view.setContent {
                                            DotNoteTheme(darkTheme = false) {
                                                SimulatedQuizCanvas(
                                                    question = customQuestion,
                                                    options = customOptions
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            // Tiny black dot overlay rendered at the exact OCR bounding box coordinate!
                            val res = liveTestResult
                            val dotBounds = res?.dotBounds
                            if (res != null && dotBounds != null && res.showDotNow) {
                                val imgW = res.ocrResult.imageWidth.coerceAtLeast(1).toFloat()
                                val imgH = res.ocrResult.imageHeight.coerceAtLeast(1).toFloat()
                                val containerWpx = with(density) { maxWidth.toPx() }
                                val scale = containerWpx / imgW
                                val containerHpx = imgH * scale

                                val dotSizePx = with(density) { settings.dotSizeDp.dp.toPx() }
                                val offsetPx = with(density) { settings.dotOffsetDp.dp.toPx() }
                                val mappedLeft = dotBounds.left * scale
                                val mappedRight = dotBounds.right * scale
                                val mappedCenterY = dotBounds.centerY() * scale

                                val candidateX = mappedLeft - dotSizePx - offsetPx
                                val xPx = if (candidateX >= 6f) {
                                    candidateX
                                } else {
                                    (mappedRight + offsetPx).coerceAtMost((containerWpx - dotSizePx - 6f).coerceAtLeast(6f))
                                }
                                val yPx = (mappedCenterY - dotSizePx / 2f)
                                    .coerceIn(6f, (containerHpx - dotSizePx - 6f).coerceAtLeast(6f))

                                Canvas(
                                    modifier = Modifier
                                        .offset { IntOffset(xPx.roundToInt(), yPx.roundToInt()) }
                                        .size(settings.dotSizeDp.dp)
                                        .testTag("active_black_dot_indicator")
                                ) {
                                    drawCircle(
                                        color = Color.White.copy(alpha = 0.4f),
                                        radius = size.minDimension / 2f + 1.5f
                                    )
                                    drawCircle(
                                        color = Color.Black,
                                        radius = size.minDimension / 2f
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { triggerCurrentScan() },
                        enabled = !isBusy,
                        modifier = Modifier
                            .weight(1.4f)
                            .height(52.dp)
                            .testTag("run_ocr_test_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        if (isBusy) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Run OCR + Match")
                    }

                    OutlinedButton(
                        onClick = {
                            imagePickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        enabled = !isBusy,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("pick_screenshot_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Image, contentDescription = "Pick screenshot", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Screenshot", maxLines = 1)
                    }
                }
            }

            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeDown,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Tip: You can also press your physical Volume Down button on this screen to trigger the test.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                AnimatedVisibility(
                    visible = liveTestResult != null,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    liveTestResult?.let { res ->
                        TestDiagnosticCard(
                            result = res,
                            dotDurationMs = settings.dotDurationMs,
                            onReplayDot = onReplayDot
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    if (showEditDialog) {
        EditTestQuizDialog(
            initialQuestion = customQuestion,
            initialOptions = customOptions,
            onDismiss = { showEditDialog = false },
            onApply = { q, opts ->
                customQuestion = q
                customOptions = opts
                showEditDialog = false
                onClearResult()
            }
        )
    }
}

@Composable
private fun SimulatedQuizCanvas(
    question: String,
    options: List<String>
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(start = 28.dp, end = 20.dp, top = 20.dp, bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = question,
            color = Color(0xFF141824),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { opt ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFF6F5F1))
                        .border(1.dp, Color(0xFFE0DDD4), RoundedCornerShape(10.dp))
                        .padding(horizontal = 14.dp, vertical = 11.dp)
                ) {
                    Text(
                        text = opt,
                        color = Color(0xFF1E222E),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

@Composable
private fun TestDiagnosticCard(
    result: LiveTestResult,
    dotDurationMs: Long,
    onReplayDot: () -> Unit
) {
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.outlinedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "OFFLINE ENGINE RESULT",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = "${result.elapsedMs} ms",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            if (result.errorMessage != null) {
                Text(
                    text = result.errorMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
            }

            result.matchResult?.let { match ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color.Black)
                        )
                        Text(
                            text = match.selectedOption.rawText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    OutlinedButton(
                        onClick = onReplayDot,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Flash ${dotDurationMs}ms Dot", style = MaterialTheme.typography.labelSmall)
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    val pct = (match.confidence * 100).roundToInt()
                    Text(
                        text = "Match Confidence: $pct% (${if (match.usedDirectMcqMatch) "Direct MCQ" else "BM25 Passage"})",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    LinearProgressIndicator(
                        progress = { match.confidence },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "MATCHED FROM: ${match.matchedSourceTitle}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = match.matchedSnippet,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EditTestQuizDialog(
    initialQuestion: String,
    initialOptions: List<String>,
    onDismiss: () -> Unit,
    onApply: (String, List<String>) -> Unit
) {
    var q by remember { mutableStateOf(initialQuestion) }
    var optA by remember { mutableStateOf(initialOptions.getOrElse(0) { "A) Option 1" }) }
    var optB by remember { mutableStateOf(initialOptions.getOrElse(1) { "B) Option 2" }) }
    var optC by remember { mutableStateOf(initialOptions.getOrElse(2) { "C) Option 3" }) }
    var optD by remember { mutableStateOf(initialOptions.getOrElse(3) { "D) Option 4" }) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Customize Test Quiz") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text("Question") })
                OutlinedTextField(value = optA, onValueChange = { optA = it }, label = { Text("Option A") }, singleLine = true)
                OutlinedTextField(value = optB, onValueChange = { optB = it }, label = { Text("Option B") }, singleLine = true)
                OutlinedTextField(value = optC, onValueChange = { optC = it }, label = { Text("Option C") }, singleLine = true)
                OutlinedTextField(value = optD, onValueChange = { optD = it }, label = { Text("Option D") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                onApply(q.trim(), listOf(optA, optB, optC, optD).map { it.trim() }.filter { it.isNotEmpty() })
            }) {
                Text("Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Suppress("DEPRECATION")
private fun decodeUriToBitmap(context: android.content.Context, uri: Uri): Bitmap? {
    return try {
        val raw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.isMutableRequired = false
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream)
            }
        } ?: return null

        // Downscale giant screenshots gently so OCR stays super fast
        val maxDim = 1600
        if (raw.width > maxDim || raw.height > maxDim) {
            val ratio = minOf(maxDim.toFloat() / raw.width, maxDim.toFloat() / raw.height)
            Bitmap.createScaledBitmap(
                raw,
                (raw.width * ratio).toInt().coerceAtLeast(1),
                (raw.height * ratio).toInt().coerceAtLeast(1),
                true
            )
        } else {
            raw
        }
    } catch (_: Throwable) {
        null
    }
}
