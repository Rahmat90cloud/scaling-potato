package com.example.engine

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class OcrLine(
    val text: String,
    val bounds: Rect,
    val blockIndex: Int
)

data class OcrScreenResult(
    val lines: List<OcrLine>,
    val fullText: String,
    val imageWidth: Int,
    val imageHeight: Int
)

object OfflineOcrProcessor {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun recognizeText(bitmap: Bitmap): OcrScreenResult =
        suspendCancellableCoroutine { continuation ->
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val extractedLines = mutableListOf<OcrLine>()
                    visionText.textBlocks.forEachIndexed { blockIdx, block ->
                        block.lines.forEach { line ->
                            val rect = line.boundingBox
                            val cleanLine = line.text.trim()
                            if (rect != null && cleanLine.isNotEmpty()) {
                                extractedLines.add(
                                    OcrLine(
                                        text = cleanLine,
                                        bounds = Rect(rect),
                                        blockIndex = blockIdx
                                    )
                                )
                            }
                        }
                    }
                    continuation.resume(
                        OcrScreenResult(
                            lines = extractedLines.sortedWith(compareBy({ it.bounds.top }, { it.bounds.left })),
                            fullText = visionText.text,
                            imageWidth = bitmap.width,
                            imageHeight = bitmap.height
                        )
                    )
                }
                .addOnFailureListener { error ->
                    continuation.resumeWithException(error)
                }
        }
}
