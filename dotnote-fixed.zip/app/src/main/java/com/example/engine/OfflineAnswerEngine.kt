package com.example.engine

import com.example.data.KnowledgeChunkEntity
import com.example.data.McqItemEntity
import kotlin.math.ln

data class OptionScore(
    val option: DetectedOption,
    val score: Float,
    val matchedSnippet: String,
    val sourceTitle: String
)

data class AnswerMatchResult(
    val selectedOption: DetectedOption,
    val confidence: Float, // 0.0 .. 1.0
    val matchedSnippet: String,
    val matchedSourceTitle: String,
    val optionScores: List<OptionScore>,
    val usedDirectMcqMatch: Boolean
)

object OfflineAnswerEngine {

    fun findBestAnswer(
        quiz: DetectedQuiz,
        chunks: List<KnowledgeChunkEntity>,
        mcqs: List<McqItemEntity>
    ): AnswerMatchResult? {
        if (quiz.options.isEmpty() || (chunks.isEmpty() && mcqs.isEmpty())) return null

        val questionTokens = TextNormalizer.tokenize(quiz.questionText)
        val questionNegated = TextNormalizer.containsNegation(quiz.questionText)

        // Stage 1: Direct MCQ / Q&A exact/fuzzy lookup
        val directResult = matchAgainstStoredMcqs(quiz, questionTokens, mcqs)
        if (directResult != null && directResult.confidence >= 0.45f) {
            return directResult
        }

        // Stage 2: Offline BM25 + Sentence Co-occurrence Passage Retrieval
        val passageResult = matchAgainstKnowledgeChunks(
            quiz = quiz,
            questionTokens = questionTokens,
            isNegated = questionNegated,
            chunks = chunks
        )

        return when {
            directResult != null && passageResult != null -> {
                if (directResult.confidence >= passageResult.confidence) directResult else passageResult
            }
            directResult != null -> directResult
            else -> passageResult
        }
    }

    private fun matchAgainstStoredMcqs(
        quiz: DetectedQuiz,
        questionTokens: List<String>,
        mcqs: List<McqItemEntity>
    ): AnswerMatchResult? {
        if (mcqs.isEmpty()) return null
        val qSet = questionTokens.toSet()

        var bestMcq: McqItemEntity? = null
        var bestQSim = 0f

        for (mcq in mcqs) {
            val storedTokens = mcq.normalizedQuestion.split(' ').filter { it.isNotEmpty() }.toSet()
            val tokenOverlap = jaccardSet(qSet, storedTokens)
            val trigramSim = TextNormalizer.jaccardTrigramSimilarity(quiz.questionText, mcq.question)
            val combinedQSim = tokenOverlap * 0.65f + trigramSim * 0.35f
            if (combinedQSim > bestQSim) {
                bestQSim = combinedQSim
                bestMcq = mcq
            }
        }

        val matchedMcq = bestMcq ?: return null
        if (bestQSim < 0.25f) return null

        val storedAnsTokens = TextNormalizer.tokenize(matchedMcq.correctAnswer).toSet()
        val storedAnsClean = TextNormalizer.cleanText(matchedMcq.correctAnswer)

        val optionScores = quiz.options.map { opt ->
            val optClean = TextNormalizer.cleanText(opt.text)
            val optTokens = TextNormalizer.tokenize(opt.text).toSet()

            val exactMatch = if (optClean == storedAnsClean || optClean.contains(storedAnsClean) || storedAnsClean.contains(optClean)) {
                1.0f
            } else 0f
            val tokenSim = jaccardSet(optTokens, storedAnsTokens)
            val triSim = TextNormalizer.jaccardTrigramSimilarity(opt.text, matchedMcq.correctAnswer)
            val ansScore = maxOf(exactMatch, tokenSim * 0.7f + triSim * 0.3f)
            val totalScore = bestQSim * 0.45f + ansScore * 0.55f

            OptionScore(
                option = opt,
                score = totalScore,
                matchedSnippet = "Q: ${matchedMcq.question}\nAns: ${matchedMcq.correctAnswer}",
                sourceTitle = matchedMcq.documentTitle
            )
        }.sortedByDescending { it.score }

        val top = optionScores.firstOrNull() ?: return null
        val secondScore = optionScores.getOrNull(1)?.score ?: 0f
        if (top.score <= 0.15f) return null

        val marginBoost = ((top.score - secondScore) * 0.5f).coerceIn(0f, 0.25f)
        val confidence = (top.score + marginBoost).coerceIn(0.05f, 0.99f)

        return AnswerMatchResult(
            selectedOption = top.option,
            confidence = confidence,
            matchedSnippet = top.matchedSnippet,
            matchedSourceTitle = top.sourceTitle,
            optionScores = optionScores,
            usedDirectMcqMatch = true
        )
    }

    private fun matchAgainstKnowledgeChunks(
        quiz: DetectedQuiz,
        questionTokens: List<String>,
        isNegated: Boolean,
        chunks: List<KnowledgeChunkEntity>
    ): AnswerMatchResult? {
        if (chunks.isEmpty()) return null

        // Build document frequency (IDF) across all stored chunks
        val totalDocs = chunks.size.coerceAtLeast(1)
        val docFreq = HashMap<String, Int>()
        val chunkTokenLists = chunks.map { chunk ->
            val list = chunk.normalizedTokens.split(' ').filter { it.isNotEmpty() }
            list.distinct().forEach { token ->
                docFreq[token] = (docFreq[token] ?: 0) + 1
            }
            list
        }

        val avgDocLen = chunkTokenLists.sumOf { it.size }.toFloat() / totalDocs.toFloat()

        fun idf(token: String): Float {
            val df = docFreq[token] ?: 0
            return ln(1f + (totalDocs - df + 0.5f) / (df + 0.5f)).coerceAtLeast(0.2f)
        }

        fun bm25Score(queryTokens: List<String>, docTokens: List<String>): Float {
            if (queryTokens.isEmpty() || docTokens.isEmpty()) return 0f
            val k1 = 1.5f
            val b = 0.75f
            val tfMap = docTokens.groupingBy { it }.eachCount()
            val docLen = docTokens.size.toFloat()
            var score = 0f
            for (qt in queryTokens.distinct()) {
                val tf = (tfMap[qt] ?: 0).toFloat()
                if (tf > 0f) {
                    val numerator = tf * (k1 + 1f)
                    val denominator = tf + k1 * (1f - b + b * (docLen / avgDocLen.coerceAtLeast(1f)))
                    score += idf(qt) * (numerator / denominator)
                }
            }
            return score
        }

        // Retrieve top-15 relevant chunks for the question (or combined question+options if question is sparse)
        val allOptionTokens = quiz.options.flatMap { TextNormalizer.tokenize(it.text) }
        val retrievalQuery = if (questionTokens.size >= 2) questionTokens else (questionTokens + allOptionTokens)

        val rankedChunks = chunks.indices.map { idx ->
            val docTokens = chunkTokenLists[idx]
            val qScore = bm25Score(retrievalQuery, docTokens)
            idx to qScore
        }.sortedByDescending { it.second }
            .take(15)

        val questionNums = TextNormalizer.extractNumericTokens(quiz.questionText)

        // Evaluate every option against the top chunks and their individual sentences
        val rawOptionScores = quiz.options.map { opt ->
            val optTokens = TextNormalizer.tokenize(opt.text)
            val optTokensUnstopped = TextNormalizer.tokenize(opt.text, removeStopWords = false, applyStemming = true)
            val effectiveOptTokens = if (optTokens.isNotEmpty()) optTokens else optTokensUnstopped
            val optClean = TextNormalizer.cleanText(opt.text)
            val optNums = TextNormalizer.extractNumericTokens(opt.text)

            var bestSupport = 0f
            var bestSnippet = chunks.first().content
            var bestSource = chunks.first().documentTitle

            for ((chunkIdx, qChunkScore) in rankedChunks) {
                val chunk = chunks[chunkIdx]
                val sentences = chunk.content.split(Regex("(?<=[.!?])\\s+|\\n+"))
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }

                // Chunk-level joint score
                val chunkTokens = chunkTokenLists[chunkIdx]
                val chunkOptBm25 = bm25Score(effectiveOptTokens, chunkTokens)
                val chunkClean = TextNormalizer.cleanText(chunk.content)
                val exactPhraseBonus = if (optClean.length >= 3 && chunkClean.contains(optClean)) 3.0f else 0f

                val chunkJointScore = (qChunkScore * 0.45f) + (chunkOptBm25 * 0.9f) +
                    (if (qChunkScore > 0f && chunkOptBm25 > 0f) (qChunkScore * chunkOptBm25 * 0.35f) else 0f) +
                    (if (qChunkScore > 0f) exactPhraseBonus else exactPhraseBonus * 0.4f)

                if (chunkJointScore > bestSupport) {
                    bestSupport = chunkJointScore
                    bestSnippet = chunk.content
                    bestSource = chunk.documentTitle
                }

                // Sentence-level fine-grained co-occurrence score (huge accuracy boost!)
                for (sentence in sentences) {
                    val sentTokens = TextNormalizer.tokenize(sentence)
                    if (sentTokens.isEmpty()) continue
                    val sentClean = TextNormalizer.cleanText(sentence)
                    val sentQMatch = bm25Score(questionTokens, sentTokens)
                    val sentOptMatch = bm25Score(effectiveOptTokens, sentTokens)

                    val optExactInSent = if (optClean.length >= 3 && sentClean.contains(optClean)) 3.5f else 0f
                    val numOverlapBonus = if (optNums.isNotEmpty()) {
                        val sentNums = TextNormalizer.extractNumericTokens(sentence)
                        val sharedNums = optNums.intersect(sentNums).size
                        if (sharedNums > 0) 2.5f * sharedNums else 0f
                    } else 0f

                    val qNumBonus = if (questionNums.isNotEmpty()) {
                        val sentNums = TextNormalizer.extractNumericTokens(sentence)
                        if (questionNums.intersect(sentNums).isNotEmpty()) 1.5f else 0f
                    } else 0f

                    val fuzzyOptBonus = if (effectiveOptTokens.size <= 3 && sentTokens.isNotEmpty()) {
                        val maxWordSim = sentTokens.maxOfOrNull { st ->
                            TextNormalizer.jaccardTrigramSimilarity(opt.text, st)
                        } ?: 0f
                        if (maxWordSim > 0.55f) maxWordSim * 2.0f else 0f
                    } else 0f

                    val coOccurrenceBoost = if ((sentQMatch > 0f || qChunkScore > 0.5f) && (sentOptMatch > 0f || optExactInSent > 0f || numOverlapBonus > 0f)) {
                        (sentQMatch + qChunkScore * 0.3f + qNumBonus) * (sentOptMatch + optExactInSent + numOverlapBonus + fuzzyOptBonus + 0.5f)
                    } else {
                        (sentOptMatch + optExactInSent + fuzzyOptBonus) * 0.4f
                    }

                    if (coOccurrenceBoost > bestSupport) {
                        bestSupport = coOccurrenceBoost
                        bestSnippet = sentence
                        bestSource = chunk.documentTitle
                    }
                }
            }

            Triple(opt, bestSupport, bestSnippet to bestSource)
        }

        // If question is negated ("Which of the following is NOT..."), invert support relative to max support
        val finalOptionScores = if (isNegated && rawOptionScores.any { it.second > 0f }) {
            val maxSupport = rawOptionScores.maxOf { it.second }
            rawOptionScores.map { (opt, support, meta) ->
                OptionScore(
                    option = opt,
                    score = (maxSupport - support).coerceAtLeast(0.05f),
                    matchedSnippet = "Negation-adjusted match against: ${meta.first}",
                    sourceTitle = meta.second
                )
            }.sortedByDescending { it.score }
        } else {
            rawOptionScores.map { (opt, support, meta) ->
                OptionScore(
                    option = opt,
                    score = support,
                    matchedSnippet = meta.first,
                    sourceTitle = meta.second
                )
            }.sortedByDescending { it.score }
        }

        val winner = finalOptionScores.firstOrNull() ?: return null
        val runnerUp = finalOptionScores.getOrNull(1)
        val totalScoreSum = finalOptionScores.sumOf { it.score.toDouble() }.toFloat().coerceAtLeast(0.001f)

        val confidence = if (winner.score <= 0f) {
            0.1f
        } else {
            val share = winner.score / totalScoreSum
            val margin = ((winner.score - (runnerUp?.score ?: 0f)) / winner.score.coerceAtLeast(0.01f)).coerceIn(0f, 1f)
            (0.35f + share * 0.40f + margin * 0.24f).coerceIn(0.15f, 0.98f)
        }

        return AnswerMatchResult(
            selectedOption = winner.option,
            confidence = confidence,
            matchedSnippet = winner.matchedSnippet,
            matchedSourceTitle = winner.sourceTitle,
            optionScores = finalOptionScores,
            usedDirectMcqMatch = false
        )
    }

    private fun jaccardSet(a: Set<String>, b: Set<String>): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        var intersection = 0
        for (item in a) {
            if (item in b) intersection++
        }
        val union = a.size + b.size - intersection
        return if (union == 0) 0f else intersection.toFloat() / union.toFloat()
    }
}
