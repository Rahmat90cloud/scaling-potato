package com.example.engine

object TextNormalizer {

    private val STOP_WORDS = setOf(
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "shall", "should",
        "can", "could", "may", "might", "must", "of", "in", "to", "for", "with",
        "on", "at", "from", "by", "about", "as", "into", "like", "through", "after",
        "over", "between", "out", "against", "during", "without", "before", "under",
        "around", "among", "and", "but", "or", "nor", "so", "yet", "both", "either",
        "neither", "that", "this", "these", "those", "which", "who", "whom", "whose",
        "what", "where", "when", "why", "how", "all", "any", "each", "every", "few",
        "more", "most", "other", "some", "such", "than", "too", "very", "just",
        "it", "its", "they", "them", "their", "we", "our", "you", "your", "he",
        "she", "his", "her", "following", "statement", "statements", "true", "correct",
        "option", "options", "select", "choose", "question", "answer", "called",
        "known", "refers", "refer", "there", "here"
    )

    private val NEGATION_WORDS = setOf(
        "not", "except", "false", "incorrect", "wrong", "never", "neither", "nor",
        "without", "least", "unlike", "cannot", "cant", "doesnt", "isnt", "arent", "wont"
    )

    private val TOKEN_REGEX = Regex("[a-z0-9]+(?:['.-][a-z0-9]+)*")
    private val NON_ALNUM_REGEX = Regex("[^a-z0-9\\s]")

    fun cleanText(input: String): String {
        return input.lowercase()
            .replace("'", "")
            .replace(NON_ALNUM_REGEX, " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun tokenize(input: String, removeStopWords: Boolean = true, applyStemming: Boolean = true): List<String> {
        val lowered = input.lowercase()
        val rawTokens = TOKEN_REGEX.findAll(lowered).map { it.value.trim('.', '-', '\'') }
        return rawTokens
            .filter { it.isNotEmpty() }
            .filter { token -> !removeStopWords || token !in STOP_WORDS || token.all(Char::isDigit) }
            .map { token -> if (applyStemming) stem(token) else token }
            .filter { it.length >= 2 || it.all(Char::isDigit) }
            .toList()
    }

    fun extractAllRawWords(input: String): List<String> {
        return TOKEN_REGEX.findAll(input.lowercase()).map { it.value }.toList()
    }

    fun containsNegation(question: String): Boolean {
        val words = extractAllRawWords(question)
        return words.any { it.replace("'", "") in NEGATION_WORDS }
    }

    fun extractNumericTokens(input: String): Set<String> {
        return Regex("\\b\\d+(?:[.,]\\d+)?\\b")
            .findAll(input)
            .map { it.value.replace(",", "") }
            .toSet()
    }

    fun stem(word: String): String {
        if (word.length <= 3 || word.all(Char::isDigit)) return word
        var w = word
        when {
            w.endsWith("ies") && w.length > 4 -> w = w.dropLast(3) + "y"
            w.endsWith("sses") && w.length > 5 -> w = w.dropLast(2)
            w.endsWith("es") && w.length > 4 && !w.endsWith("ses") && !w.endsWith("zes") -> w = w.dropLast(2)
            w.endsWith("s") && !w.endsWith("ss") && w.length > 3 -> w = w.dropLast(1)
        }
        when {
            w.endsWith("ation") && w.length > 6 -> w = w.dropLast(5)
            w.endsWith("ment") && w.length > 5 -> w = w.dropLast(4)
            w.endsWith("ness") && w.length > 5 -> w = w.dropLast(4)
            w.endsWith("ing") && w.length > 5 -> w = w.dropLast(3)
            w.endsWith("ed") && w.length > 4 -> w = w.dropLast(2)
            w.endsWith("ly") && w.length > 4 -> w = w.dropLast(2)
        }
        return w
    }

    fun charTrigrams(text: String): Set<String> {
        val clean = cleanText(text).replace(" ", "_")
        if (clean.length < 3) return if (clean.isEmpty()) emptySet() else setOf(clean)
        val result = HashSet<String>(clean.length)
        for (i in 0..clean.length - 3) {
            result.add(clean.substring(i, i + 3))
        }
        return result
    }

    fun jaccardTrigramSimilarity(a: String, b: String): Float {
        val triA = charTrigrams(a)
        val triB = charTrigrams(b)
        if (triA.isEmpty() || triB.isEmpty()) return 0f
        var intersection = 0
        for (t in triA) {
            if (t in triB) intersection++
        }
        val union = triA.size + triB.size - intersection
        return if (union == 0) 0f else intersection.toFloat() / union.toFloat()
    }
}
