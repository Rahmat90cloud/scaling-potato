package com.example.engine

import android.graphics.Rect

data class DetectedOption(
    val index: Int,
    val label: String?, // e.g. "A", "B", "1"
    val text: String,
    val rawText: String,
    val bounds: Rect
)

data class DetectedQuiz(
    val questionText: String,
    val options: List<DetectedOption>,
    val allLinesText: String
)

object ScreenQuizParser {

    private val EXPLICIT_OPTION_REGEX = Regex(
        "^\\s*(?:[\\(\\[]?([A-Ea-e1-5])[\\)\\].:\\-]|[•○●\\*\\-])\\s+(.+)$"
    )
    private val LETTER_ONLY_PREFIX_REGEX = Regex(
        "^\\s*[\\(\\[]?([A-Ea-e1-5])[\\)\\].:\\-]\\s*$"
    )
    private val QUESTION_STARTER_REGEX = Regex(
        "^(?:what|which|who|whom|whose|where|when|why|how|define|identify|select|choose|calculate|find|name|state|explain|which of)\\b.*",
        RegexOption.IGNORE_CASE
    )
    private val NOISE_LINE_REGEX = Regex(
        "^(?:\\d{1,2}:\\d{2}(?:\\s?[AP]M)?|\\d{1,3}%|5G|4G|LTE|Wi-Fi|Back|Next|Submit|Skip|Previous)$",
        RegexOption.IGNORE_CASE
    )

    fun parse(ocrResult: OcrScreenResult): DetectedQuiz? {
        val height = ocrResult.imageHeight.coerceAtLeast(1)
        val width = ocrResult.imageWidth.coerceAtLeast(1)

        // Filter out status bar / bottom system bar noise and tiny single-char artifacts
        val filteredLines = ocrResult.lines.filter { line ->
            val centerY = line.bounds.centerY().toFloat() / height.toFloat()
            val text = line.text.trim()
            val notSystemChrome = centerY in 0.04f..0.95f
            val notUiButtonNoise = !NOISE_LINE_REGEX.matches(text)
            notSystemChrome && notUiButtonNoise && text.length >= 2
        }

        if (filteredLines.isEmpty()) return null

        // Merge detached single-letter option badges (e.g. "A)" at x=60 and "Mitochondria" at x=120 on same row)
        val mergedLines = mergeSameRowOptionBadges(filteredLines, width)

        // Strategy 1: Find explicit prefixed options (A), B), 1., •, etc.)
        val explicitOptions = mutableListOf<Pair<Int, DetectedOption>>()
        mergedLines.forEachIndexed { idx, line ->
            val match = EXPLICIT_OPTION_REGEX.find(line.text)
            if (match != null) {
                val label = match.groupValues[1].uppercase().ifEmpty { null }
                val optionBody = match.groupValues[2].trim()
                if (optionBody.isNotEmpty()) {
                    explicitOptions.add(
                        idx to DetectedOption(
                            index = explicitOptions.size,
                            label = label,
                            text = optionBody,
                            rawText = line.text,
                            bounds = line.bounds
                        )
                    )
                }
            }
        }

        if (explicitOptions.size >= 2) {
            val firstOptionLineIdx = explicitOptions.first().first
            val questionLines = mergedLines.take(firstOptionLineIdx)
                .map { it.text }
                .takeLast(6)
            val questionText = buildQuestionText(questionLines, mergedLines)
            return DetectedQuiz(
                questionText = questionText,
                options = explicitOptions.mapIndexed { i, pair -> pair.second.copy(index = i) },
                allLinesText = mergedLines.joinToString("\n") { it.text }
            )
        }

        // Strategy 2: Structural quiz detection (question line followed by 2..6 stacked answer lines)
        val questionIdx = findLikelyQuestionIndex(mergedLines)
        if (questionIdx >= 0 && questionIdx < mergedLines.lastIndex) {
            // Combine multi-line question wrapping around questionIdx
            val qStart = (questionIdx - 2).coerceAtLeast(0)
            var qEnd = questionIdx
            while (qEnd > 0 && !mergedLines[qEnd].text.endsWith("?") &&
                qEnd + 1 < mergedLines.size &&
                (mergedLines[qEnd + 1].bounds.top - mergedLines[qEnd].bounds.bottom) < height * 0.025f
            ) {
                qEnd++
            }
            val questionText = mergedLines.subList(qStart, qEnd + 1)
                .joinToString(" ") { it.text }
                .trim()

            // Group remaining lines below question by block or vertical gap into candidate options
            val candidateLines = mergedLines.drop(qEnd + 1)
            val optionGroups = groupOptionBlocks(candidateLines, height)
            if (optionGroups.size >= 2) {
                val options = optionGroups.take(6).mapIndexed { i, group ->
                    val combinedText = group.joinToString(" ") { it.text }.trim()
                    val unionRect = Rect(group.first().bounds).apply {
                        group.forEach { union(it.bounds) }
                    }
                    DetectedOption(
                        index = i,
                        label = ('A' + i).toString(),
                        text = combinedText,
                        rawText = combinedText,
                        bounds = unionRect
                    )
                }
                return DetectedQuiz(
                    questionText = questionText,
                    options = options,
                    allLinesText = mergedLines.joinToString("\n") { it.text }
                )
            }
        }

        // Strategy 3: Fallback — treat all blocks after the first block as options
        val blocks = mergedLines.groupBy { it.blockIndex }.values.toList()
        if (blocks.size >= 3) {
            val questionText = blocks.first().joinToString(" ") { it.text }
            val options = blocks.drop(1).take(6).mapIndexed { i, blk ->
                val txt = blk.joinToString(" ") { it.text }
                val rect = Rect(blk.first().bounds).apply { blk.forEach { union(it.bounds) } }
                DetectedOption(
                    index = i,
                    label = ('A' + i).toString(),
                    text = txt,
                    rawText = txt,
                    bounds = rect
                )
            }
            return DetectedQuiz(
                questionText = questionText,
                options = options,
                allLinesText = mergedLines.joinToString("\n") { it.text }
            )
        }

        return null
    }

    private fun mergeSameRowOptionBadges(lines: List<OcrLine>, screenWidth: Int): List<OcrLine> {
        val result = mutableListOf<OcrLine>()
        var i = 0
        while (i < lines.size) {
            val curr = lines[i]
            if (i + 1 < lines.size && LETTER_ONLY_PREFIX_REGEX.matches(curr.text)) {
                val next = lines[i + 1]
                val verticalOverlap = kotlin.math.abs(curr.bounds.centerY() - next.bounds.centerY()) <=
                    maxOf(curr.bounds.height(), next.bounds.height()) * 0.8f
                val horizontalGap = next.bounds.left - curr.bounds.right
                if (verticalOverlap && horizontalGap in -20..(screenWidth / 3)) {
                    val unionRect = Rect(curr.bounds).apply { union(next.bounds) }
                    result.add(
                        OcrLine(
                            text = "${curr.text.trim()} ${next.text.trim()}",
                            bounds = unionRect,
                            blockIndex = next.blockIndex
                        )
                    )
                    i += 2
                    continue
                }
            }
            result.add(curr)
            i++
        }
        return result
    }

    private fun findLikelyQuestionIndex(lines: List<OcrLine>): Int {
        // Prefer lines ending with '?' or containing '____'
        val qMarkIdx = lines.indexOfFirst { it.text.contains("?") || it.text.contains("___") }
        if (qMarkIdx >= 0 && qMarkIdx < lines.lastIndex) return qMarkIdx

        // Or lines starting with interrogative words
        val starterIdx = lines.indexOfFirst { QUESTION_STARTER_REGEX.matches(it.text) }
        if (starterIdx >= 0 && starterIdx < lines.lastIndex) return starterIdx

        return if (lines.size >= 3) 0 else -1
    }

    private fun groupOptionBlocks(lines: List<OcrLine>, screenHeight: Int): List<List<OcrLine>> {
        if (lines.isEmpty()) return emptyList()
        val groups = mutableListOf<MutableList<OcrLine>>()
        var currentGroup = mutableListOf(lines.first())
        val lineBreakThreshold = (screenHeight * 0.018f).coerceAtLeast(16f)

        for (i in 1 until lines.size) {
            val prev = lines[i - 1]
            val curr = lines[i]
            val gap = curr.bounds.top - prev.bounds.bottom
            val sameBlock = curr.blockIndex == prev.blockIndex && gap < lineBreakThreshold
            if (sameBlock) {
                currentGroup.add(curr)
            } else {
                groups.add(currentGroup)
                currentGroup = mutableListOf(curr)
            }
        }
        groups.add(currentGroup)
        return groups.filter { grp ->
            val combined = grp.joinToString(" ") { it.text }.trim()
            combined.length >= 2 && combined.length <= 220
        }
    }

    private fun buildQuestionText(aboveLines: List<String>, allLines: List<OcrLine>): String {
        val candidate = aboveLines.joinToString(" ").trim()
        if (candidate.isNotEmpty()) return candidate
        return allLines.firstOrNull()?.text ?: ""
    }
}
