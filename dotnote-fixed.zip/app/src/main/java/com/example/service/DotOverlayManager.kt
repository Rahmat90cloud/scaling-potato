package com.example.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class DotOverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var activeDotView: View? = null
    private var dismissRunnable: Runnable? = null

    fun showDotBesideBounds(
        optionBounds: Rect,
        screenWidth: Int,
        screenHeight: Int,
        dotSizeDp: Float = 10f,
        offsetDp: Float = 10f,
        durationMs: Long = 500L
    ) {
        mainHandler.post {
            removeCurrentDotImmediate()

            val dotPx = dpToPx(dotSizeDp).coerceAtLeast(10)
            val gapPx = dpToPx(offsetDp).coerceAtLeast(6)
            val paddingPx = 4
            val totalViewSize = dotPx + paddingPx * 2

            // Prefer placing the tiny black dot immediately to the left of the selected option;
            // if the option starts too close to the left screen edge, place it just to the right.
            val candidateLeftX = optionBounds.left - totalViewSize - gapPx
            val x = if (candidateLeftX >= 6) {
                candidateLeftX
            } else {
                (optionBounds.right + gapPx).coerceAtMost((screenWidth - totalViewSize - 6).coerceAtLeast(6))
            }
            val y = (optionBounds.centerY() - totalViewSize / 2)
                .coerceIn(12, (screenHeight - totalViewSize - 12).coerceAtLeast(12))

            val dotView = BlackSignalDotView(context, dotPx)
            val params = WindowManager.LayoutParams(
                totalViewSize,
                totalViewSize,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                this.x = x
                this.y = y
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }

            try {
                windowManager.addView(dotView, params)
                activeDotView = dotView
                val hideTask = Runnable { removeCurrentDotImmediate() }
                dismissRunnable = hideTask
                mainHandler.postDelayed(hideTask, durationMs)
            } catch (_: Throwable) {
                activeDotView = null
            }
        }
    }

    fun cleanup() {
        mainHandler.post { removeCurrentDotImmediate() }
    }

    private fun removeCurrentDotImmediate() {
        dismissRunnable?.let { mainHandler.removeCallbacks(it) }
        dismissRunnable = null
        activeDotView?.let { view ->
            try {
                windowManager.removeViewImmediate(view)
            } catch (_: Throwable) {
            }
        }
        activeDotView = null
    }

    private fun dpToPx(dp: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            context.resources.displayMetrics
        ).toInt()
    }

    private class BlackSignalDotView(
        context: Context,
        private val dotDiameterPx: Int
    ) : View(context) {
        private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(65, 255, 255, 255)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.FILL
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val radius = dotDiameterPx / 2f
            canvas.drawCircle(cx, cy, radius + 1f, haloPaint)
            canvas.drawCircle(cx, cy, radius, dotPaint)
        }
    }
}
