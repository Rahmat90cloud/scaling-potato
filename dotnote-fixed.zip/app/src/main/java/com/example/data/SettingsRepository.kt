package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "dotnote_settings")

data class TriggerSettings(
    val isServiceArmed: Boolean = true,
    val consumeVolumeKey: Boolean = true,
    val dotSizeDp: Float = 10f,
    val dotDurationMs: Long = 500L,
    val dotOffsetDp: Float = 10f
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val IS_SERVICE_ARMED = booleanPreferencesKey("is_service_armed")
        val CONSUME_VOLUME_KEY = booleanPreferencesKey("consume_volume_key")
        val DOT_SIZE_DP = floatPreferencesKey("dot_size_dp")
        val DOT_DURATION_MS = longPreferencesKey("dot_duration_ms")
        val DOT_OFFSET_DP = floatPreferencesKey("dot_offset_dp")
    }

    val settingsFlow: Flow<TriggerSettings> = context.dataStore.data.map { prefs ->
        TriggerSettings(
            isServiceArmed = prefs[Keys.IS_SERVICE_ARMED] ?: true,
            consumeVolumeKey = prefs[Keys.CONSUME_VOLUME_KEY] ?: true,
            dotSizeDp = prefs[Keys.DOT_SIZE_DP] ?: 10f,
            dotDurationMs = prefs[Keys.DOT_DURATION_MS] ?: 500L,
            dotOffsetDp = prefs[Keys.DOT_OFFSET_DP] ?: 10f
        )
    }

    suspend fun getCurrentSettings(): TriggerSettings = settingsFlow.first()

    suspend fun setServiceArmed(armed: Boolean) {
        context.dataStore.edit { it[Keys.IS_SERVICE_ARMED] = armed }
    }

    suspend fun setConsumeVolumeKey(consume: Boolean) {
        context.dataStore.edit { it[Keys.CONSUME_VOLUME_KEY] = consume }
    }

    suspend fun setDotSizeDp(sizeDp: Float) {
        context.dataStore.edit { it[Keys.DOT_SIZE_DP] = sizeDp.coerceIn(6f, 20f) }
    }

    suspend fun setDotDurationMs(durationMs: Long) {
        context.dataStore.edit { it[Keys.DOT_DURATION_MS] = durationMs.coerceIn(250L, 2000L) }
    }

    suspend fun setDotOffsetDp(offsetDp: Float) {
        context.dataStore.edit { it[Keys.DOT_OFFSET_DP] = offsetDp.coerceIn(4f, 24f) }
    }
}
