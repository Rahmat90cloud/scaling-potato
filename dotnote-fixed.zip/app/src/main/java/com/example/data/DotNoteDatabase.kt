package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        KnowledgeDocumentEntity::class,
        KnowledgeChunkEntity::class,
        McqItemEntity::class,
        MatchHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class DotNoteDatabase : RoomDatabase() {
    abstract fun knowledgeDao(): KnowledgeDao
    abstract fun matchHistoryDao(): MatchHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: DotNoteDatabase? = null

        fun getInstance(context: Context): DotNoteDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DotNoteDatabase::class.java,
                    "dotnote_knowledge.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
