package com.example

import android.app.Application
import com.example.data.DotNoteDatabase
import com.example.data.KnowledgeRepository
import com.example.data.SettingsRepository

class DotNoteApplication : Application() {
    val database: DotNoteDatabase by lazy { DotNoteDatabase.getInstance(this) }
    val knowledgeRepository: KnowledgeRepository by lazy {
        KnowledgeRepository(
            knowledgeDao = database.knowledgeDao(),
            matchHistoryDao = database.matchHistoryDao()
        )
    }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
}
