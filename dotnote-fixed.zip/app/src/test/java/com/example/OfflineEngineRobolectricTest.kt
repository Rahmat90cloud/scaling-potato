package com.example

import android.content.Context
import android.graphics.Rect
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.DotNoteDatabase
import com.example.data.KnowledgeRepository
import com.example.engine.KnowledgeParser
import com.example.engine.OcrLine
import com.example.engine.OcrScreenResult
import com.example.engine.OfflineAnswerEngine
import com.example.engine.ScreenQuizParser
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class OfflineEngineRobolectricTest {

    private lateinit var db: DotNoteDatabase
    private lateinit var repository: KnowledgeRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, DotNoteDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = KnowledgeRepository(db.knowledgeDao(), db.matchHistoryDao())
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `parses study notes and MCQs and stores them in Room SQLite`() = runTest {
        val text = """
            Mitochondria generate most of the cell's supply of ATP as chemical energy.
            Chloroplasts conduct photosynthesis in plant cells using sunlight.

            Q: Which transport protocol is connectionless?
            A) TCP
            B) UDP
            C) FTP
            D) SSH
            Answer: B
        """.trimIndent()

        val result = repository.ingestPastedText("Bio & Net Notes", text).getOrThrow()
        assertTrue(result.chunkCount >= 1)
        assertEquals(1, result.mcqCount)

        val (chunks, mcqs) = repository.getAllChunksAndMcqs()
        assertTrue(chunks.isNotEmpty())
        assertEquals("UDP", mcqs.first().correctAnswer)
    }

    @Test
    fun `matches passage fact from OCR bounds accurately`() = runTest {
        val notes = """
            The Golgi apparatus modifies, sorts, and packages proteins and lipids for secretion.
            The mitochondrion is the powerhouse of the cell because it produces adenosine triphosphate (ATP).
            Ribosomes translate messenger RNA into polypeptide chains.
        """.trimIndent()

        repository.ingestPastedText("Cell Biology", notes).getOrThrow()
        val (chunks, mcqs) = repository.getAllChunksAndMcqs()

        val ocr = OcrScreenResult(
            lines = listOf(
                OcrLine("Which organelle produces ATP for cellular energy?", Rect(60, 220, 950, 300), 0),
                OcrLine("A) Golgi apparatus", Rect(80, 360, 620, 420), 1),
                OcrLine("B) Mitochondrion", Rect(80, 450, 620, 510), 2),
                OcrLine("C) Ribosome", Rect(80, 540, 620, 600), 3),
                OcrLine("D) Nucleus", Rect(80, 630, 620, 690), 4)
            ),
            fullText = "",
            imageWidth = 1080,
            imageHeight = 2400
        )

        val parsedQuiz = ScreenQuizParser.parse(ocr)
        assertNotNull(parsedQuiz)
        assertEquals(4, parsedQuiz!!.options.size)

        val match = OfflineAnswerEngine.findBestAnswer(parsedQuiz, chunks, mcqs)
        assertNotNull(match)
        assertEquals("B", match!!.selectedOption.label)
        assertEquals("Mitochondrion", match.selectedOption.text)
        assertEquals(Rect(80, 450, 620, 510), match.selectedOption.bounds)
    }

    @Test
    fun `matches direct MCQ from stored knowledge even with detached letter badges`() = runTest {
        val raw = """
            Q: What is the time complexity of binary search on a sorted array?
            A) O(n)
            B) O(n log n)
            C) O(log n)
            D) O(1)
            Answer: C
        """.trimIndent()

        repository.ingestPastedText("Algorithms", raw).getOrThrow()
        val (chunks, mcqs) = repository.getAllChunksAndMcqs()

        val ocr = OcrScreenResult(
            lines = listOf(
                OcrLine("What is the time complexity of binary search?", Rect(60, 250, 960, 320), 0),
                OcrLine("A)", Rect(60, 380, 110, 430), 1),
                OcrLine("O(n)", Rect(130, 380, 320, 430), 2),
                OcrLine("B)", Rect(60, 460, 110, 510), 3),
                OcrLine("O(log n)", Rect(130, 460, 380, 510), 4),
                OcrLine("C)", Rect(60, 540, 110, 590), 5),
                OcrLine("O(1)", Rect(130, 540, 320, 590), 6)
            ),
            fullText = "",
            imageWidth = 1080,
            imageHeight = 2400
        )

        val quiz = ScreenQuizParser.parse(ocr)!!
        assertEquals(3, quiz.options.size)
        val match = OfflineAnswerEngine.findBestAnswer(quiz, chunks, mcqs)!!
        assertEquals("O(log n)", match.selectedOption.text)
    }
}
